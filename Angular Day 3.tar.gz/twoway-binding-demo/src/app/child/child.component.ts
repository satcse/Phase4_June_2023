import { Component, OnInit , EventEmitter} from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
  inputs:[`pdata`],
  outputs:[`cevent`]
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  //pdata is the INPUT data coming into Child Component from Parent Component.
  public pdata:string;

  //cevent is the event emitter which this Child Component uses to OUTPUT data from Child Component to Parent Component.
  cevent = new EventEmitter<string>();

  onChange(value:string)
  {
    this.cevent.emit(value);
  }

}
