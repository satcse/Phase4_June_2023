import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private formBuilder: FormBuilder){}
  submitted = false;
  registerForm: FormGroup;

  //Automaticaly execute this ngOnInit() method during first time load into the Angular Server.
  ngOnInit()
  {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });
  }

  get f()
  {
    return this.registerForm.controls;
  }

  onSubmit()
  {
    this.submitted = true;

    //Do the form Validation and stop the Submit process if the form is invalid.
    if(this.registerForm.invalid)
    {
      return;
    }

    //Submit the form successfully now.
    alert('Your request has been submitted for approval')
  }


}
