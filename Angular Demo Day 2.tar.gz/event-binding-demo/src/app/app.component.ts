import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'event-binding-demo';
  data='';

  fsd(event)
  {
    console.log(event.target.value);
  }

  onKeyDown(event)
  {
    console.log(event.target.value);
    this.data = this.data + event.target.value+" | ";
  }
}
